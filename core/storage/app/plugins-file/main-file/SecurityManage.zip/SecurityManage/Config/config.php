<?php

return [
    'name' => 'SecurityManage'
];
